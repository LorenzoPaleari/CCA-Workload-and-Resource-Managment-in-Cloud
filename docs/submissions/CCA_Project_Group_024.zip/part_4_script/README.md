# How to use it

## Environment variables
Source the variables with `source env.sh`

## Python script
```
./main.py <command>
```
### Commands:
- `create`: creates the cluster and install `mcperf` to the three clients. It requires the path to the yaml configuration file (`-f <filename>`).
- `status`: get the current status of the cluster.
- `ssh <node-name>`: open a ssh connection to the specified node. It requires the key `cloud-computing-24` to be stored in `~/.ssh/`.
- `test -s <scheduler-name> -o <output-file-name>`: executes the scheduler specified. `<scheduler-name>` must be the name of the file in the `schedulers/` directory without the `.py` extension. `<output-file-name>` is the name of the file mcperf is going to generate.
- `destroy`: deletes all the resources allocated for the cluster.
- `time` -r <result-dir>: download every file generated during testing and put them in the specified folder: `<result-dir>` must be the path to the folder.

For more info run `--help`.

### Dynamic scheduler
```
./main.py test -s static -p yaml/parsec_static
```

### INFO
The scheduler itself is inside the `schedulers/` folder. 
